package com.adel.banshar
import android.content.Intent
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
class Adapter(private var items:List<Customer>):BaseAdapter(){
 fun setItems(v:List<Customer>){items=v;notifyDataSetChanged()}
 override fun getCount()=items.size;override fun getItem(p:Int)=items[p];override fun getItemId(p:Int)=items[p].id
 override fun getView(p:Int,cv:View?,parent:ViewGroup):View{val v=cv?:LayoutInflater.from(parent.context).inflate(R.layout.item_customer,parent,false);val c=items[p]
  v.findViewById<TextView>(R.id.name).text=c.name
  v.findViewById<TextView>(R.id.details).text="${c.vehicle.ifBlank{"بدون سيارة"}} • ${c.oilType.ifBlank{"نوع زيت غير محدد"}}"
  v.findViewById<TextView>(R.id.countdown).text=countdown(c.nextDate)
  v.findViewById<TextView>(R.id.due).text=if(c.remaining>0)"المستحق: ${fmt(c.remaining)} ريال" else "لا يوجد مستحق"
  v.findViewById<Button>(R.id.edit).setOnClickListener{parent.context.startActivity(Intent(parent.context,CustomerActivity::class.java).putExtra("id",c.id))};return v }
 private fun countdown(s:String):String=try{val f=SimpleDateFormat("yyyy-MM-dd",Locale.US);val target=f.parse(s)?:Date();var ms=target.time-Date().time;val day=86_400_000L;if(ms<=0)"موعد تغيير الزيت الآن" else {val d=ms/day;ms%=day;val h=ms/3_600_000;ms%=3_600_000;val m=ms/60_000;"متبقي لتغيير الزيت: ${d}ي ${h}س ${m}د"}}catch(_:Exception){"موعد الزيت غير محدد"}
 private fun fmt(x:Double)=String.format(Locale.US,"%.0f",x)
}
