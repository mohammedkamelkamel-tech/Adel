package com.adel.banshar
import android.app.Activity
import android.content.Intent
import android.net.Uri
import java.io.File
class BackupManager(private val a:Activity){
 fun create(){val i=Intent(Intent.ACTION_CREATE_DOCUMENT);i.type="application/octet-stream";i.putExtra(Intent.EXTRA_TITLE,"banshar-adel-backup.db");a.startActivityForResult(i,9101)}
 fun restore(){val i=Intent(Intent.ACTION_OPEN_DOCUMENT);i.type="application/octet-stream";i.addCategory(Intent.CATEGORY_OPENABLE);a.startActivityForResult(i,9102)}
 fun handle(r:Int,data:Intent?){val u=data?.data?:return;try{when(r){9101->write(u);9102->read(u)}}catch(e:Exception){android.widget.Toast.makeText(a,"فشل النسخ الاحتياطي: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}}
 private fun write(u:Uri){a.contentResolver.openOutputStream(u)?.use{out->File(a.getDatabasePath("banshar.db").absolutePath).inputStream().use{it.copyTo(out)}};android.widget.Toast.makeText(a,"تم حفظ النسخة الاحتياطية",android.widget.Toast.LENGTH_SHORT).show()}
 private fun read(u:Uri){a.contentResolver.openInputStream(u)?.use{input->File(a.getDatabasePath("banshar.db").absolutePath).outputStream().use{input.copyTo(it)}};android.widget.Toast.makeText(a,"تم استرجاع النسخة. أغلق التطبيق وافتحه من جديد",android.widget.Toast.LENGTH_LONG).show()}
}
