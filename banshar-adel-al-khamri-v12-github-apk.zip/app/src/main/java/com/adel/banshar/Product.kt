package com.adel.banshar

data class Product(val id:Long=0,val name:String,val category:String,val unit:String,val quantity:Double,val purchasePrice:Double,val salePrice:Double,val minStock:Double,val createdAt:String,val barcode:String=""){ override fun toString() = "${name} | ${String.format(java.util.Locale.US,"%.0f",quantity)} ${unit} | بيع: ${String.format(java.util.Locale.US,"%.0f",salePrice)} ريال" }
data class SaleRow(val id:Long,val productId:Long,val productName:String,val unit:String,val quantity:Double,val unitPrice:Double,val total:Double,val paid:Double,val remaining:Double,val customerId:Long,val customerName:String,val kind:String,val serviceType:String,val soldAt:String,val invoiceNo:String="")
data class ExpenseRow(val id:Long,val title:String,val amount:Double,val note:String,val spentAt:String)
